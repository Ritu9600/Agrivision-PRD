import { Card, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css";
//import {useState} from 'react';
import "/src/styles.css";

function Card1() {
  return (
    <div id="small2">
      <Card className="cardsurvey" style={{ width: "70%" }}>
        <Card.Body>
          <Card.Title>
            <h1>
              Hello <span className="title">Student!</span>
            </h1>
          </Card.Title>
          <Card.Text>
            <h6>help us know you better</h6>
            <h6 className="cardtext">
              Which exam/s are you looking to conquer?
            </h6>
          </Card.Text>
          <span className="btn">
            <Card className="exam">
              <Button className="btn1">GATE</Button>
            </Card>
          </span>
          <span className="btn">
            <Card className="exam">
              <Button className="btn1">CFTRI</Button>
            </Card>
          </span>
          <span className="btn">
            <Card className="exam">
              <Button className="btn1">CFO/TO</Button>
            </Card>
          </span>
          <span className="btn">
            <Card className="exam">
              <Button className="btn1">ICAR</Button>
            </Card>
          </span>
          <div>
            <span>
              <Button className="btn3" id="btn3">
                Back
              </Button>
            </span>
            <span>
              <Button className="btn3" id="btn4">
                Next
              </Button>
            </span>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
}

export default Card1;

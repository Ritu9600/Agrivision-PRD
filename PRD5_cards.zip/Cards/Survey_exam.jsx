import { Card, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css";
//import {useState} from 'react';
import "/src/styles.css";

function Card2() {
  return (
    <div id="small2">
      <Card className="cardsurvey" style={{ width: "70%" }}>
        <Card.Body>
          <Card.Title>
            <h1>
              Hello <span className="title">Student!</span>
            </h1>
          </Card.Title>
          <Card.Text>
            <h6>help us know you better</h6>
            <h6 className="cardtext">
              How prepared do you feel to crack this exam/s?
            </h6>
          </Card.Text>
          <span className="btn">
            <Card className="exam1">
              <Button className="btn1">Confident </Button>
            </Card>
          </span>
          <span className="btn">
            <Card className="exam1">
              <Button className="btn1">Maybe, I can crack it</Button>
            </Card>
          </span>
          <span className="btn">
            <Card className="exam1">
              <Button className="btn1">I don't feel prepared</Button>
            </Card>
          </span>
          <h6 className="cardtext2">
          Yayy! You just need some questions to practice and you will be good to go.
           Don’t forget to check our <a className="link" href="/home">Text Series</a> section!
            </h6>
          <div>
            <span>
              <Button className="btn3" id="btn3">
                Previous
              </Button>
            </span>
            <span>
              <Button className="btn3" id="btn4">
                Next
              </Button>
            </span>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
}

export default Card2;

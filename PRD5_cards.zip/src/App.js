import "./styles.css";
import Card1 from "/Cards/Survey";
import Card2 from "/Cards/Survey_exam";
//import Card2 from "/Cards/Survey_exam";
export default function App() {
  return (
    
    <div className="App">
     <Card1/>
     <Card2/>
    </div>
    
  );
}
